<?php
// Entra directo al login
header('Location: public/login.php');
exit;
