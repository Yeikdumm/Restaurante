<?php
// Proxy para que funcione /Restaurante/login.php
require __DIR__ . '/public/login.php';
